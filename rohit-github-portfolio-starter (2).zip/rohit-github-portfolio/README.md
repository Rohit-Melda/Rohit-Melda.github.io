# Rohit's Developer Portfolio

A responsive, animated personal portfolio built with vanilla HTML, CSS, and JavaScript. It is designed for GitHub Pages.

## Files
- `index.html` — page structure and content
- `style.css` — dark modern styling, responsive layout, animations
- `script.js` — typing effect, reveal-on-scroll, mobile navigation, reading progress

## Personalize before publishing
1. Open `script.js`.
2. Replace `YOUR_GITHUB_USERNAME` with your GitHub username.
3. Replace `YOUR_EMAIL@example.com` with an email address you want people to use.
4. In `index.html`, replace the sample project descriptions and the three `https://github.com/` project links with your actual projects.
5. Edit the About and Skills sections so they accurately reflect your experience.

## Publish with GitHub Pages
1. Create a **public** repository named exactly `YOUR-USERNAME.github.io`.
2. Upload `index.html`, `style.css`, and `script.js` to the repository root (not inside another folder).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for the Pages deployment to finish. Your site will be at `https://YOUR-USERNAME.github.io`.

## GitHub profile README
The separate `profile-README.md` file in this starter pack is a template for your GitHub profile. To activate it, create another public repository named exactly your GitHub username and put its contents in that repository's `README.md`.

No framework, build step, or paid hosting is required.
